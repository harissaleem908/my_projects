import 'package:flutter/material.dart';

class Blacklist_Users extends StatefulWidget {
  const Blacklist_Users({Key? key}) : super(key: key);

  @override
  State<Blacklist_Users> createState() => _Blacklist_UsersState();
}

class _Blacklist_UsersState extends State<Blacklist_Users> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
