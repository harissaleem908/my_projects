import 'package:flutter/material.dart';

class BlocklistTrainers extends StatefulWidget {
  const BlocklistTrainers({Key? key}) : super(key: key);

  @override
  State<BlocklistTrainers> createState() => _BlocklistTrainersState();
}

class _BlocklistTrainersState extends State<BlocklistTrainers> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
