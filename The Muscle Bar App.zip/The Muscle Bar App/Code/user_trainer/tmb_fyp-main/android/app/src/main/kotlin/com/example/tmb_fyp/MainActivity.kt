package com.example.tmb_fyp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
